var searchData=
[
  ['cli_5fpoo_0',['CLI_POO',['../namespace_c_l_i___p_o_o.html',1,'']]]
];

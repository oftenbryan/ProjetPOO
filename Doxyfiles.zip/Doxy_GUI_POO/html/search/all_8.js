var searchData=
[
  ['label1_0',['label1',['../namespace_g_u_i___p_o_o.html#aa97ea574f414535a926d0435057b7c2d',1,'GUI_POO']]]
];

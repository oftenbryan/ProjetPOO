var searchData=
[
  ['relheight_0',['relheight',['../namespace_g_u_i___p_o_o.html#a12f46ae3684dba36a67abf782c794e2d',1,'GUI_POO']]],
  ['relwidth_1',['relwidth',['../namespace_g_u_i___p_o_o.html#a097229f0b1b3648cdef15bf4be3c1562',1,'GUI_POO']]]
];
